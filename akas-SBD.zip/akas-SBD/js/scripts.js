var toggle = 0;
$( "#sidebarToggle" ).click(function() {
    if(toggle == 0){
        $("#layoutSidenav_nav").css("width", "0px");
        $(".selected").css("width", "0px");
        toggle = 1;
    } else if (toggle == 1) {
        $("#layoutSidenav_nav").css("width", "230px");
        $(".selected").css("width", "230px");
        toggle = 0;
    }
});